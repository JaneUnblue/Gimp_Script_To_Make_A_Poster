#!/usr/bin/env python

from gimpfu import *

def poster(file1, file2, file3, file4, file5, file6, text, text2, fontsize, font, colorBack, colorFore, hue_offset, lightness, saturation, img2_opacity):
    imgW, imgH = 2480, 3508
    img = gimp.Image(imgW, imgH, RGB)
    gimp.message("created a new image")

    pdb.gimp_context_set_background(colorBack)
    pdb.gimp_context_set_foreground(colorFore)
    gimp.message("created colors")
    

    image1 = pdb.file_png_load(file1, file1)
    pdb.gimp_image_scale(image1, imgW, imgH)

    layer1 = pdb.gimp_layer_new_from_visible(image1, img, "Background")
    pdb.gimp_image_insert_layer(img, layer1, None, len(img.layers))

    textLayer = pdb.gimp_text_fontname(img, None, imgW/2, imgH*6/7+10, text, 10, True, fontsize, PIXELS, font)
    textLayer.translate(-textLayer.width/2, -textLayer.height/2)
    textLayer2 = pdb.gimp_text_fontname(img, None, imgW/2, imgH*6/7 + 155, text2, 10, True, fontsize, PIXELS, font)
    textLayer2.translate(-textLayer2.width/2, -textLayer2.height/2)
    gimp.message("created text")

   

    def add_image_layer(file, pos_x, pos_y, layer_name, width, adjust_hue=False, opacity=100):
        image = pdb.file_png_load(file, file)
        
        original_width = image.width
        original_height = image.height
        scale_factor = float(width) / original_width
        new_height = int(original_height * scale_factor)
        
        pdb.gimp_image_scale(image, width, new_height)
        pdb.gimp_edit_copy(image.layers[0])
        imageLayer = gimp.Layer(img, layer_name, width, new_height, RGBA_IMAGE, 100, NORMAL_MODE)
        img.add_layer(imageLayer, 1)
        pdb.gimp_layer_add_alpha(imageLayer)
        floatingLayer = pdb.gimp_edit_paste(imageLayer, True)
        pdb.gimp_floating_sel_anchor(floatingLayer)
        imageLayer.translate(pos_x, pos_y)
        pdb.gimp_layer_set_opacity(imageLayer, opacity)

        if adjust_hue:
            drawable = pdb.gimp_image_get_active_layer(img)
            pdb.gimp_drawable_hue_saturation(drawable, 2, hue_offset, lightness, saturation, 0)

    add_image_layer(file2, imgW/11 -100, imgH/14-80, "image 2", 900, opacity=img2_opacity)
    add_image_layer(file3, imgW/2 - 925, imgH*1/8-60, "image 3", 1950)
    add_image_layer(file4, imgW/2 - 1075, imgH*1/8-80, "image 4", 2150, adjust_hue=True)
    add_image_layer(file5, imgW/2 - 900, imgH*2/3-40, "image 5", 1800)
    add_image_layer(file6, imgW/2 + 360, imgH/3+340, "image 6", 880)

    gimp.Display(img)
    gimp.displays_flush()

register(
    "python_fu_poster", 
    "A_Dog_Called_Money Poster",
    "Create a new image with 6 images",
    "YZ",
    "Copyright@YZ",
    "2023",
    "A_Dog_Called_Money Poster",
    "",
    [
        (PF_FILE, "file1", "Choose Image 1", ""),
        (PF_FILE, "file2", "Choose Image 2", ""),
        (PF_FILE, "file3", "Choose Image 3", ""),
        (PF_FILE, "file4", "Choose Image 4", ""),
        (PF_FILE, "file5", "Choose Image 5", ""),
        (PF_FILE, "file6", "Choose Image 6", ""),
        (PF_STRING, "text", "Choose Copyright", "Tracing Wealth,"),
        (PF_STRING, "text2", "Enter Second Line", "Unveiling the Secrets of Money."),
        (PF_SPINNER, "fontsize", "Font Size", 130, (10, 200, 5)),
        (PF_FONT, "font", "Choose Font", "Gill Sans Bold"),
        (PF_COLOR, "colorBack", "Background Color", (255,255,0)),
        (PF_COLOR, "colorFore", "Foreground Color", (47,46,56)),
        (PF_SLIDER, "hue_offset", "Hue Offset for Image 4", -3, (-180, 180, 1)),
        (PF_SLIDER, "lightness", "Lightness for Image 4", 32, (-100, 100, 1)),
        (PF_SLIDER, "saturation", "Saturation for Image 4", 34.8, (-100, 100, 1)),

        (PF_SLIDER, "img2_opacity", "Opacity for Image 2", 67, (0, 100, 1)),
    ],
    [],
    poster,
    menu="<Image>/File/Create/Assign2"
)

main()
